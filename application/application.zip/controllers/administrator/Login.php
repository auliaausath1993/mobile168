<?php

/* Class Main */
class Login extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
	}	
	
	public function index()
	{
		$this->load->view('administrator/page_login');
	}
	
	public function logout()
	{
		$this->load->library('auth');
		$this->auth->logout();
	}
	
	public function login_process()
	{		
		$this->form_validation->set_rules('username','Username','required');
		$this->form_validation->set_rules('password','Password','required');
		
		if($this->form_validation->run() == TRUE)
		{	
			$username = $this->input->post('username');
			$password = $this->input->post('password');
			
			$this->load->model('Admin_model');
			
			$check = $this->Admin_model->check_user($username,$password);
			
			if ($check == TRUE)
			{
				$this->load->model('main_model');
				$get_data_user = $this->main_model->get_detail('users',array('user_name' => $username));
				$pincode = $this->main_model->get_detail('content', array('name' => 'pincode'));
				$data = array(
					'webadmin_login'      => TRUE,
					'webadmin_user_id'    => $get_data_user['id'],
					'webadmin_user_name'  => $get_data_user['user_name'],
					'webadmin_user_token' => sha1($password),
					'user_akses_menu'     => explode(',', $get_data_user['akses_menu']),
					'webadmin_user_level' => $get_data_user['user_level'],
					'pincode'             => $pincode['value']
				);
						
				$this->session->set_userdata($data);
				redirect('administrator/main');
			}
			else if($check == FALSE)
			{	
				$this->session->set_flashdata('message','<div class="alert alert-error">Maaf, Username dan Password tidak cocok</div>');
				redirect('administrator/login');
			}
		}
		else
		{
			$this->session->set_flashdata('message','<div class="alert alert-error">Maaf, Lengkapi Terlebih dahulu Form Anda</div>');
			redirect('administrator/login');
		}	
	}
}	