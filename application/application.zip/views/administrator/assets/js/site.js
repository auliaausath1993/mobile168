
function open_gallery()
{	
	$("#popup-window").show();
	$("#popup-window .inner .content").load(base_url+"backend/gallery/product");
}

function open_gallery()
{	
	$("#popup-window").show();
	$("#popup-window .inner .content").load(base_url+"backend/gallery/product");
}


function close_popup()
{	
	$("#popup-window").hide();
	return false;
}

$('.datepicker').datepicker();
	