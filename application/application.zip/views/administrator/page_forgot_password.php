<!DOCTYPE html>

<html lang="en"><head>

<meta http-equiv="content-type" content="text/html; charset=UTF-8">

    <title>Forgot Password Admin</title>

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <meta charset="utf-8">

	

    <link rel="stylesheet" href="<?= base_url() ?>application/views/administrator/assets/bootstrap/css/bootstrap.css" media="screen">

	<link rel="stylesheet" href="<?= base_url() ?>application/views/administrator/assets/css/login.css" media="all">





    <link href="<?= base_url() ?>application/views/administrator/assets/bootstrap/css/bootstrap-responsive.css" rel="stylesheet">



    <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->

    <!--[if lt IE 9]>

      <script src="../assets/js/html5shiv.js"></script>

    <![endif]-->



    <!-- Fav and touch icons -->

    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="../assets/ico/apple-touch-icon-144-precomposed.png">

    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="../assets/ico/apple-touch-icon-114-precomposed.png">

    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="../assets/ico/apple-touch-icon-72-precomposed.png">

    <link rel="apple-touch-icon-precomposed" href="../assets/ico/apple-touch-icon-57-precomposed.png">

    <link rel="shortcut icon" href="../assets/ico/favicon.png">

    <style>
      	body {
      		<?php 
			$login_background_image = $this->main_model->get_detail('content',array('name' => 'login_background_image'));
			if ($login_background_image['value'] == null) {
				$img = base_url('media/images/bg_login.jpg');
			} else {
				$img = base_url('media/images/'.$login_background_image['value']);
			} ?>
      		background: url('<?= $img ?>') no-repeat center top; /* Old browsers */
      	}

      	.bottom-navbar {
      		<?php 
			$header_color = $this->main_model->get_detail('content',array('name' => 'header_color'));
      		$font_color = $this->main_model->get_detail('content',array('name' => 'font_color')); ?>

      		background:  <?= $header_color['value'] ?>;
      		color: <?= $font_color['value'] ?>;
      	}
	</style>

  </head>

  <?php 
    $data_version = $this->main_model->get_list('data_version_update',array('perpage' => 1,'offset' => 0),array('by' => 'id','sorting' => 'DESC'));
    $data_array_version_last = $data_version->row_array();
    $name_last_vertion = $data_array_version_last['name_version'];
  ?>


  <body>



    <div class="container">

	<?= $this->session->flashdata('message'); ?>

  <div id="alret_sucsess" class="alert alert-sucsess" role="alert" hidden>
    <strong>Activation Sucsess : </strong>UTerimakasih anda telah berhasil melakukan activasi.
  </div>

	<br/><br/><br/><br/>

     <?=form_open('administrator/forgot/check_email_user',array('class' => 'form-signin')); ?>

        

		<h4>Halaman Forgot Password</h4>
		
		<h5>Masukan Email :</h5>

        <input type="text" class="input-block-level" name="email" placeholder="Alamat email account user anda">
		
        <button class="btn btn-large btn-inverse" type="submit" data-loading-text="Loading.. ">Kirim</button>

     <?=form_close()?>



	<center>

	<p class="powered">Powered by <b><?=$this->config->item('tokomobile_online_shop'); ?> </b>Ver. <?php echo $name_last_vertion; ?><br/>

	Aplikasi Smartphone Online Shop

	</p>

	

	</center>

    </div>

	<div class="bottom-navbar"><strong><?=$this->config->item('tokomobile_online_shop'); ?></strong>

	</div>

    <script src="<?= base_url() ?>application/views/administrator/assets/js/jquery.js"></script>

    <script src="<?= base_url() ?>application/views/administrator/assets/bootstrap/js/bootstrap.js"></script>

	<script src="<?= base_url() ?>application/views/administrator/assets/js/jquery.js"></script>

	<script>

		setTimeout("$('.form-signin').fadeIn('slow');",400);

		setTimeout("$('.powered').fadeIn('slow');",1000);

    $.post( base_url+"administrator/activation/activation_process", { code: code, expired_date: data.expired_date, paket: data.paket, token: data.token},
       function( data ) {

          if(data.status == 'Success')
          {
              $('#alret_sucsess').modal('show');
          }  

    }, "json");

	</script>

</body>

</html>

