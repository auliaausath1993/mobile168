<?php $uri = $this->uri->segment(3) ?>
<ul class="nav navbar-nav side-nav">
	<li>
		<a href="<?=base_url()?>administrator/main"  class="tipped" data-title="Untuk kembali ke halaman utama" ><i class="fa fa-fw fa-dashboard"></i> Dashboard</a>
	</li>
    <?php
    	$user_id = $this->session->userdata('webadmin_user_id');
    	$user_login = $this->db->get_where('users', array('id' => $user_id))->row_array();
        $user_akses_menu = explode(',', $user_login['akses_menu']);
    	if (in_array('product_category', $user_akses_menu) || in_array('methode_pembayaran', $user_akses_menu) || in_array('customer', $user_akses_menu) || in_array('customertype', $user_akses_menu)) { ?>
    <li>
        <a href="javascript:;" data-toggle="collapse" data-target=".master"><i class="fa fa-fw fa-table"></i> Master <i class="fa fa-fw fa-caret-down"></i>
        	<?php if ($data_customer['total'] > 0) { ?>
				<span class="label label-danger"><?=$data_customer['total']?></span>
			<?php } ?>
        </a>
        <ul class="collapse master <?php if ($uri == 'product_category' OR $uri == 'methode_pembayaran' OR $uri == 'customer' OR $uri == 'customertype'){echo 'in';} ?>">
        <?php if (in_array('product_category', $user_akses_menu)) { ?>
            <li>
                <a href="<?=base_url()?>administrator/main/product_category" class="tipped" data-title="Untuk melihat & menambahkan data kategori pada produk">Product Category</a>
            </li>
        <?php } if (in_array('methode_pembayaran', $user_akses_menu)) { ?>
            <li>
                <a href="<?=base_url()?>administrator/main/methode_pembayaran" class="tipped" data-title="Untuk menambahkan data metode pembayaran">Payment Methode</a>
            </li>
        <?php } if (in_array('customer', $user_akses_menu)) { ?>
            <li>
		        <a href="<?=base_url()?>administrator/main/customer" class="tipped" data-title="Untuk melihat keseluruhan data pelanggan">Data Customer
					<?php if ($data_customer['total'] > 0) { ?>
					<span class="label label-danger"><?=$data_customer['total']?></span>
				<?php } ?>
				</a>
		    </li>
		<?php } if (in_array('suplier', $user_akses_menu)) { ?>
		    <li>
		        <a href="#" class="tipped" data-title="Untuk melihat keseluruhan data suplier">Data Suplier / Vendor
				</a>
		    </li>
		<?php } if (in_array('customertype', $user_akses_menu)) { ?>
		    <li>
		        <a href="<?=base_url()?>administrator/main/customertype" class="tipped" data-title="Untuk melihat data kategori pelanggan">Customer Category</a>
		    </li>
		<?php } ?>
        </ul>
    </li>
    <?php } if (in_array('purchase', $user_akses_menu)) { ?>
    <li>
        <a href="javascript:;" data-toggle="collapse" data-target=".purchase"><i class="fa fa-fw fa-list"></i> Purchase<i class="fa fa-fw fa-caret-down"></i></a>
        <ul class="collapse purchase <?php if ($uri == 'report_per_day' OR $uri == 'report_per_day_process' OR $uri == 'report_per_month' OR $uri == 'report_per_month_process' OR $uri == 'report_pembayaran_perday' OR $uri == 'report_pembayaran_perday_process' OR $uri == 'report_pembayaran_permonth' OR $uri == 'report_pembayaran_permonth_process' ){echo 'in';} ?>">
        </ul>
    </li>
    <?php } if (in_array('stock', $user_akses_menu) || in_array('add_product', $user_akses_menu)) { ?>
    <li>
        <a href="javascript:;" data-toggle="collapse" data-target=".stok"><i class="fa fa-fw fa-list"></i> Stock<i class="fa fa-fw fa-caret-down"></i></a>
        <ul class="collapse stok <?php if ($uri == 'stock' OR $uri == 'add_product') {echo 'in';} ?>">
        <?php if (in_array('stock', $user_akses_menu)) { ?>
            <li>
               <a href="<?=base_url()?>administrator/main/stock" class="tipped <?php if ( $uri == 'stock' OR $uri == 'search_product_stock' ){echo "active";} ?>" data-title="Untuk melihat dan menambahkan jumlah stock yang ada pada produk anda">Stock</a>
            </li>
        <?php } if (in_array('add_product', $user_akses_menu)) { ?>
            <li>
                  <a href="<?=base_url()?>administrator/main/add_product/ready_stock" class="tipped <?php if ( $uri == 'add_product' && $this->uri->segment(4) == 'ready_stock' ){echo "active";} ?>" data-title="Untuk menambahkan produk baru pada katalog Ready Stock & <br/> melihat keseluruhan data produk pada katalog Ready Stock yang telah ditampilkan">Add Product Ready</a>
            </li>
            <li>
                <a href="<?=base_url()?>administrator/main/add_product/pre_order" class="tipped <?php if ( $uri == 'add_product' && $this->uri->segment(4) == 'pre_order' ){echo "active";} ?>" data-title="Untuk menambahkan produk baru pada katalog Pre Order & <br/> melihat keseluruhan data produk pada katalog Pre Order yang telah ditampilkan"> Add Product Pre-Order</a>
            </li>
        <?php } ?>
        </ul>
    </li>
    <?php } if (in_array('last_order_process', $user_akses_menu) || in_array('order_rekap', $user_akses_menu) || in_array('order_dropship', $user_akses_menu) || in_array('order_paid', $user_akses_menu) || in_array('create_order', $user_akses_menu)) { ?>
	<li>
		<a href="javascript:;" data-toggle="collapse" data-target=".penjualan"><i class="fa fa-fw fa-shopping-cart"></i> Penjualan <i class="fa fa-fw fa-caret-down"></i></a>
		<ul class="collapse <?php if ($uri == 'last_order_process' OR $uri == 'last_order_search' OR $uri == 'last_order_process_by_variant' OR $uri == 'product_last_order_result' OR $uri == 'last_order_process_expired' OR $uri == 'order_unpaid' OR $uri == 'list_pesanan_per_variant' OR $uri == 'master_data_search' OR $uri == 'order_paid' OR $uri == 'create_order' OR $uri == 'create_order_tamu' OR $uri == 'order_dropship' OR $uri == 'order_rekap' OR $uri == 'scan_order'){echo 'in';} ?> penjualan">
		<?php if (in_array('last_order_process', $user_akses_menu)) { ?>
			<li>
				<a href="<?=base_url()?>administrator/main/last_order_process" class="tipped" data-title="Untuk melihat data pesanan dalam proses berdasarkan pesanan terakhir"> Pesanan On Proses</a>
			</li>
		<?php } if (in_array('order_rekap', $user_akses_menu)) { ?>
             <li>
                <a href="<?=base_url()?>administrator/main/order_rekap" class="tipped" data-title="Untuk melihat keseluruhan data pesanan (Nota) yang sudah direkap">Pesanan Rekap</a>
            </li>
        <?php } if (in_array('order_dropship', $user_akses_menu)) { ?>
            <li>
                <a href="<?=base_url()?>administrator/main/order_dropship" class="tipped" data-title="Untuk melihat keseluruhan data pesanan (Nota) yang sudah dropship">Pesanan Dropship</a>
            </li>
        <?php } if (in_array('order_paid', $user_akses_menu)) { ?>
            <li>
                <a href="<?=base_url()?>administrator/main/order_paid" class="tipped" data-title="Untuk melihat keseluruhan data pesanan (Nota) yang sudah lunas">Pesanan Lunas</a>
            </li>
        <?php } if (in_array('create_order', $user_akses_menu)) { ?>
            <li>
                <a href="<?=base_url()?>administrator/main/create_order" class="tipped <?php if ($uri == 'create_order_tamu'){echo "active";} ?>" data-title="Untuk membuat pesanan baru">Buat Pesanan</i></a>
            </li>
          <?php } if (in_array('scan_order', $user_akses_menu)) { ?>
         	<li>
                <a href="<?=base_url()?>administrator/main/scan_order" class="tipped <?php if ($uri == 'create_order_tamu'){echo "active";} ?>" data-title="Untuk scan pesanan menjadi lunas">Scan Pesanan</i></a>
            </li>
        <?php } ?>
		</ul>
   </li>
   <?php } if (in_array('master_data_pesanan', $user_akses_menu) || in_array('report_per_day', $user_akses_menu) || in_array('report_pembayaran_perday', $user_akses_menu)) { ?>
    <li>
        <a href="javascript:;" data-toggle="collapse" data-target=".laporan"><i class="fa fa-fw fa-list"></i> Laporan<i class="fa fa-fw fa-caret-down"></i></a>
        <ul class="collapse laporan <?php if ($uri == 'report_per_day' OR $uri == 'report_per_day_process' OR $uri == 'report_per_month' OR $uri == 'report_per_month_process' OR $uri == 'report_pembayaran_perday' OR $uri == 'report_pembayaran_perday_process' OR $uri == 'report_pembayaran_permonth' OR $uri == 'report_pembayaran_permonth_process' OR $uri == 'report_assets' ){echo 'in';} ?>">
        <?php if (in_array('master_data_pesanan', $user_akses_menu)) { ?>
            <li>
                <a href="<?=base_url()?>administrator/main/master_data_pesanan" class="tipped <?php if ($uri == 'master_data_search'){ echo "active"; } ?>" data-title="Untuk mencari seluruh data pesanan"> Master Data Pesanan</a>
            </li>
        <?php } if (in_array('report_per_day', $user_akses_menu)) { ?>
            <li>
                <a href="<?=base_url()?>administrator/main/report_per_day" class="tipped <?php if ( $uri == 'report_per_day' OR $uri == 'report_per_day_process' OR $uri == 'report_per_month' OR $uri == 'report_per_month_process' ){echo "active"; } ?>" data-title="Untuk melihat keseluruhan laporan pesanan yang telah terjadi  per hari maupun per bulan">Laporan Pesanan</span></a>
            </li>
        <?php } if (in_array('report_pembayaran_perday', $user_akses_menu)) { ?>
            <li>
                <a href="<?=base_url()?>administrator/main/report_pembayaran_perday" class="tipped <?php if ( $uri == 'report_pembayaran_perday_process' OR $uri == 'report_pembayaran_perday' OR $uri == 'report_pembayaran_permonth_process' ){echo "active"; } ?>" data-title="Untuk melihat keseluruhan laporan pembayaran yang telah terjadi per hari maupun per bulan ">Laporan Pembayaran</span></a>
            </li>
        <?php } if (in_array('report_autocancel', $user_akses_menu)) { ?>
            <li>
                <a href="<?=base_url()?>administrator/main/report_autocancel" class="tipped <?php if ( $uri == 'report_pembayaran_perday_process' OR $uri == 'report_pembayaran_permonth' OR $uri == 'report_pembayaran_permonth_process' OR $uri == 'report_autocancel'){echo "active"; } ?>" data-title="Untuk melihat keseluruhan laporan autocancel">Laporan Autocancel</span></a>
            </li>
        <?php } if (in_array('report_assets', $user_akses_menu)) { ?>
            <li>
                <a href="<?=base_url()?>administrator/main/report_assets" class="tipped <?php if ($uri == 'report_assets'){echo "active"; } ?>" data-title="Untuk melihat keseluruhan laporan autocancel">Laporan Assets</span></a>
            </li>
        <?php } ?>
        </ul>
    </li>
    <?php } if (in_array('confirm_payment', $user_akses_menu) || in_array('resi_pengiriman', $user_akses_menu)) { ?>
    <li>
        <a href="javascript:;" data-toggle="collapse" data-target=".info"><i class="fa fa-fw fa-info-circle"></i> Informasi Pembayaran & Resi<i class="fa fa-fw fa-caret-down"></i></a>
        <ul class="collapse info <?php if ($uri == 'confirm_payment' OR $uri == 'resi_pengiriman'){echo 'in';} ?>">
        	<?php if (in_array('confirm_payment', $user_akses_menu)) { ?>
			 <li>
		        <a href="<?=base_url()?>administrator/main/confirm_payment" class="tipped" data-title="Untuk melihat data konfirmasi pembayaran dari pelanggan">Konfirmasi Pembayaran</a>
		    </li>
		    <?php } if ( in_array('resi_pengiriman', $user_akses_menu)) { ?>
			 <li>
		        <a href="<?=base_url()?>administrator/main/resi_pengiriman" class="tipped" data-title="Untuk menginputkan data resi pengiriman">Data Resi & Pengiriman</a>
		    </li>
		   	<?php } ?>
        </ul>
    </li>
    <?php } if (in_array('message_add', $user_akses_menu) || in_array('chatting', $user_akses_menu)) {
    	$data_tiket_status =  $this->db->select('COUNT(*) AS total')
    		->get_where('chatting',array('status' => 'Unread','sender' => 'Customer'))->row_array();
    	$data_chat_product =  $this->db->select('COUNT(*) AS total')
    		->get_where('chat_product', array('read_chat' => 0, 'sender' => 'Customer'))->row_array(); ?>
    <li>
        <a href="javascript:;" data-toggle="collapse" data-target=".cs"><i class="fa fa-fw fa-envelope"></i>  Customer Service<i class="fa fa-fw fa-caret-down"></i> <span class="label label-danger qty-chat-product-chat"><?=$data_tiket_status['total'] + $data_chat_product['total'] ?></span></a>
        <ul class="collapse cs <?php if ($uri == 'message_add' || $uri == 'chatting' || $uri == 'chat_product'){echo 'in';} ?>">
        <?php if (in_array('message_add', $user_akses_menu)) { ?>
		    <li>
		        <a href="<?=base_url()?>administrator/main/message_add" class="tipped" data-title="Untuk membuat pesan ke pelanggan secara individu">Kirim Pesan</a>
		    </li>
		<?php } if (in_array('chatting', $user_akses_menu)) { ?>
		    <li>
		        <a href="<?=base_url()?>administrator/main/chatting" class="tipped" data-title="Untuk chatting ke pelanggan secara individu">
		        Chatting <span class="label label-danger qty-chat"><?=$data_tiket_status['total']?></span></a>
		    </li>
		<?php } if (in_array('chat_product', $user_akses_menu)) { ?>
		    <li>
		        <a href="<?=base_url()?>administrator/main/chat_product" class="tipped" data-title="Data chat produk dari pelanggan">
		        Chat Product <span class="label label-danger qty-chat-product"><?=$data_chat_product['total']?></span></a>
		    </li>
		<?php } ?>
        </ul>
    </li>
    <?php } if (in_array('edit_info/toko', $user_akses_menu) || in_array('home_slideshow', $user_akses_menu) || in_array('edit_info/stok', $user_akses_menu) || in_array('edit_info/image', $user_akses_menu) || in_array('edit_info/nota', $user_akses_menu) || in_array('edit_info/link', $user_akses_menu) || in_array('edit_info/aplikasi', $user_akses_menu) || in_array('ekspedisi', $user_akses_menu) || in_array('content_faq', $user_akses_menu)) { ?>
    <li>
        <a href="javascript:;" data-toggle="collapse" data-target=".pengaturan"><i class="fa fa-fw fa-gear"></i> Pengaturan<i class="fa fa-fw fa-caret-down"></i></a>
        <ul class="collapse pengaturan <?php if ($uri == 'tarif_ekspedisi' OR $uri == 'edit_info' OR $uri == 'methode_pembayaran' OR $uri == 'ekspedisi_jne_prov' OR $uri == 'ekspedisi_jne_kota' OR $uri == 'home_slideshow'  OR $uri == 'content_faq'){echo 'in';} ?>">
        <?php if (in_array('edit_info/toko', $user_akses_menu)) { ?>
            <li>
                <a href="<?=base_url()?>administrator/main/edit_info/toko" class="tipped" data-title="Untuk pengaturan toko online anda">Data Toko Online</a>
            </li>
        <?php } if (in_array('home_slideshow', $user_akses_menu)) { ?>
            <li>
                <a href="<?=base_url()?>administrator/main/home_slideshow">Pengaturan Slideshow</a>
            </li>
        <?php } if (in_array('edit_info/stok', $user_akses_menu)) { ?>
            <li>
                <a href="<?=base_url()?>administrator/main/edit_info/stok">Pengaturan Stok</a>
            </li>
        <?php } if (in_array('edit_info/image', $user_akses_menu)) { ?>
            <li>
                <a href="<?=base_url()?>administrator/main/edit_info/image">Pengaturan Image</a>
            </li>
        <?php } if (in_array('edit_info/nota', $user_akses_menu)) { ?>
            <li>
                <a href="<?=base_url()?>administrator/main/edit_info/nota">Format Nota</a>
            </li>
        <?php } if (in_array('edit_info/link', $user_akses_menu)) { ?>
            <li>
                <a href="<?=base_url()?>administrator/main/edit_info/link">Pengaturan Link Aplikasi</a>
            </li>
        <?php } if (in_array('edit_info/aplikasi', $user_akses_menu)) { ?>
            <li>
                <a href="<?=base_url()?>administrator/main/edit_info/aplikasi">Pengaturan Aplikasi</a>
            </li>
        <?php } if (in_array('edit_info/ekspedisi', $user_akses_menu)) { ?>
            <li>
                <a href="<?=base_url()?>administrator/main/edit_info/ekspedisi">Pengaturan Ekspedisi</a>
            </li>
        <?php } if (in_array('content_faq', $user_akses_menu)) { ?>
            <li>
                <a href="<?=base_url()?>administrator/main/content_faq/edit/21">FAQ</a>
            </li>
        <?php } ?>
        </ul>
    </li>
    <?php } if (in_array('users_management', $user_akses_menu)) { ?>
     <li>
            <a href="<?= base_url()?>administrator/main/users_management"><i class="fa fa-fw fa-users"></i> Manajemen User</a>
        </li>
     <?php } ?>
     <?php if ($this->tokomobile_white_label == "Yes") { ?>
        <li>
            <a href="<?= base_url()?>administrator/main/info_paket"><i class="fa fa-fw fa-medkit"></i> Informasi Paket</a>
        </li>
    <?php } ?>
	<li>
        <a href="<?=base_url()?>administrator/main/logout" class="tipped" data-title="Untuk keluar dari halaman administrator anda"><i class="fa fa-fw fa-power-off"></i> Keluar</a>
    </li>
</ul>