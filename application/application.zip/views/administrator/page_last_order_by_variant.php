<?php include "includes/header.php"; 
error_reporting(E_ALL ^ (E_NOTICE));
?>
<script type="text/javascript">
var table_name = '<?= $table_name; ?>';
</script>
<!-- Content
================================================== -->
<div id="page-wrapper">

    <div class="container-fluid">

	   	<!-- Page Heading -->
	    <div class="row">
	        <div class="col-lg-12">
	            <h1 class="page-header">
	                Pesanan <small> Dalam Proses</small>
	            </h1>
	            <ul id="submenu-container" class="nav nav-tabs" style="margin-bottom: 20px;">
                  	<li><a href="<?=base_url()?>administrator/main/last_order_process" ><b>Keep (Belum Lunas)</b></a></li>
                  	<li class="active"><a href="<?=base_url()?>administrator/main/last_order_process_by_variant" ><b>Keep Per Produk</b></a></li>
                	<li><a href="<?=base_url()?>administrator/main/order_unpaid" ><b>Dropship Belum Lunas</b></a></li>
                	 <li>
						<a href="<?=base_url()?>administrator/main/last_order_process_expired" >
							<b>Jatuh Tempo (Keep)</b>
						</a>
					</li> 
					<li><a href="<?=base_url()?>administrator/main/order_unpaid_expired" ><b>Jatuh Tempo (Dropship)</b></a></li>
                </ul>
				 <ol class="breadcrumb">
	                <li class="active">
	                    <i class="fa fa-fw fa-list"></i> Pesanan Per Produk
	                </li>
	            </ol>
	        </div>
	    </div>
	    <!-- /.row -->
		<div>
		<div class="search-wrapper row" style="margin-bottom: 15px;">
			<div class="search-name-wrapper col-sm-offset-8  col-sm-4">
				<form name="form1" id="form1" method="post" action="<?=base_url()?>administrator/main/search_product_last_order_session" >
					<input type='text' id='name_product' name='name_product' class="autocomplete_pro input-text col-sm-10" placeholder="Nama Produk" style="padding: 6px; margin-right: 5px;" />
				
					<button  type="submit" class="btn btn-info"><i class="fa fa-search"></i></button>
				</form>
			</div>
		</div>
		<table class="table table-bordered">
			<thead>
				<tr class="btn-info">
					<td>NO</td>
					<td>Produk</td>
					<td>Varian</td>
					<td>Pesanan</td>
					<td class="text-center">Action</td>
				</tr>
			</thead>
			<?php 
			$i = 1 * ($offset + 1);
			foreach($list_product->result() as $list):
			
			$data_pesanan=$this->main_model->get_list_where('orders_item',array('variant_id' => $list->variant_id,'order_payment'=>'Unpaid','order_status'=>'Keep'));
			$total_pesanan = $data_pesanan->num_rows();
			$data_variant = $this->main_model->get_detail('product_variant',array('id' => $list->variant_id));
			$data_product = $this->main_model->get_detail('product',array('id' => $data_variant['prod_id']));
			?>
			<tbody>
				<tr>
					<td><?=$i ?></td>
					<td><?=$data_product['name_item'] ?></td>
					<td><?=$data_variant['variant'] ?></td>
					<td><?=$total_pesanan?></td>
					<td class="text-center"><a href="<?=base_url() ?>administrator/main/list_pesanan_per_variant/<?=$list->variant_id ?>" class="btn btn-primary" >Lihat Pesanan</a></td>
					
				</tr>
			</tbody>
			
			<?php 
				$i++;
				endforeach;
			?>
			
		</table>
		</div>
		<?=$this->pagination->create_links(); ?>
    	<?=$this->session->flashdata('message') ?>
		<?=$output->output; ?>
		<br/>
    </div>
    

 </div>

<?php include "includes/footer.php"; ?>
<script type="text/javascript" src="https://code.jquery.com/jquery-1.8.1.min.js"></script>
<script type='text/javascript' src='<?php echo base_url();?>assets/js/jquery.autocomplete.js'></script>

<?php if($output->output != null) { ?>
	<?php foreach($output->js_files as $file): ?>
	<script src="<?php echo $file; ?>"></script>
	<?php endforeach; ?>
	<?php } ?>