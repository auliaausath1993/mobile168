<?php include "includes/header.php"; ?>

<script type="text/javascript">

var table_name = '<?= $table_name; ?>';

</script>

<!-- Content
================================================== -->

<div id="page-wrapper">

    <div class="container-fluid">

		<div class="row">

	        <div class="col-lg-12">
	            <h1 class="page-header">
	                Add Customer
	            </h1>
	            <ol class="breadcrumb">
				
	                <li class="active">

	                    <i class="fa fa-fw fa-edit"></i> Add Customer

	                </li>

	            </ol>

	        </div>

	    </div>
	    <!-- /.row -->
		<div class="row">
			
			<div class="col-lg-12">
			<?=$this->session->flashdata('message') ?>
				<div class="table-responsive add-product-wrapper">
				<form method="post" action="<?=base_url()?>administrator/main/add_customer_process" id="form-add-customer">
					<table class="table table-bordered table-striped">
						<tbody>
							<tr>
								<td width="25%">Nama Customer*</td>
								<td><input type="text" id="name-item" name ="name" class="input-text" title="masukkan nama customer anda" value="<?=$this->session->flashdata('customer') ?>" required ></td>
							</tr>
							<tr>
								<td width="25%">Email*</td>
								<td><input type="text" id="harga-modal" name ="email" class="input-text" title="masukkan Email customer anda" value="<?=$this->session->flashdata('email') ?>" required ></td>
							</tr>
							<tr>
								<td width="25%">Password*</td>
								<td><input type="text" id="harga-jual" name ="password" class="input-text" required></td>
							</tr>
							<tr>
								<td width="25%">Alamat</td>
								<td>
									<textarea id="deskripsi" name ="alamat" class="input-text" title="masukkan Alamat customer anda" maxlength="180" ><?=$this->session->flashdata('alamat') ?></textarea><br/>
								</td>
							</tr>
							
							<tr>
								<td width="25%">Provinsi*</td>
								<td>
									<select name="provinsi" class="select-text" id="provinsi" required>
										<option value="">- Pilih Provinsi -</option>
										
									</select>
								</td>
							</tr>
							<tr>
								<td width="25%">Kota*</td>
								<td>
									<select name="kota" class="select-text" id="kota" required>
										<option value="">- Pilih Kota -</option>
									</select>
								</td>
							</tr>
							<tr>
								<td width="25%">Kecamatan*</td>
								<td>
									<select name="kecamatan" class="select-text" id="kecamatan" required>
										<option value="">- Pilih Kecamatan -</option>
									</select>
								</td>
							</tr>
							
							<tr>
								<td width="25%">Kode Pos</td>
								<td><input type="text" id="harga-jual" name ="postcode" class="input-text" ></td>
							</tr>
							<tr>
								<td width="25%">Phone</td>
								<td><input type="text" id="harga-jual" name ="phone" class="input-text" ></td>
							</tr>
							<tr>
								<td width="25%">Pin BB</td>
								<td><input type="text" id="harga-jual" name ="pinbb" class="input-text" ></td>
							</tr>
							<tr>
								<td width="25%">Jenis Customer*</td>
								<td>
									<select name="jenis_customer" class="select-text" id="jenis_customer" required>
										<option value="Lokal">Lokal</option>
										<option value="Luar">Luar</option>
									</select>
								</td>
							</tr>
							<tr>
								<td width="25%">Status*</td>
								<td>
									<select name="status" class="select-text" id="status" required>
										<option value="Active">Active</option>
										<option value="Inactive">Inactive</option>
										<option value="Moderate">Moderate</option>
									</select>
								</td>
							</tr>
						</tbody>
					</table>
				</div>
				<div class="buttons-addproduct-wrapper">


					<input type="hidden" name="redirect_url" id="redirect_url"  value="" />
					<a href="#" id="add-back" class="btn btn-lg btn-default">Save</a>
					<button type="submit" id="add-product" class="btn btn-lg btn-default">Save and Back to List</button>
					<input type="hidden" name="this_redirect_url" id="this_redirect_url"  value="administrator/main/add_new_customer" />	
					
					<a href="<?=base_url()?>administrator/main/customer" class="btn btn-lg btn-default">Cancel</a>
					
				</div>
				</form>
			</div>
		</div>
    	

    </div>
 </div>

<?php include "includes/footer.php"; ?>

<script>

	
		
	var base_url_api = "http://api.tokomobile.co.id/ongkir/development/api";
	var token_api = "<?=$this->config->item('tokomobile_token')?>";
	var domain_api = "<?=$this->config->item('tokomobile_domain')?>";
	
	$.get(base_url_api+"/province",{token : token_api,domain : domain_api},
	function(data)
	{
		if(data.status == 'Success')
		{
			var list_data = data.result;
			var list_length = data.result.length;
			
			for(var i = 0; i < list_length; i++)
			{
				var prov = "<option value='"+list_data[i].province_id+"'>"+list_data[i].province+"</option>";
				
				$("#provinsi").append(prov);
			}
		}
			
	},"json");
	
	$("#provinsi").change(function(){
		
		var province_id = $(this).val(); 
		$("#kota").html("<option value=''>Loading..</option>");
		$("#kecamatan").html("<option value=''>- Pilih Kecamatan -</option>");
		//Get List Kota
		$.get(base_url_api+"/city",{token : token_api,domain : domain_api, province_id : province_id},function(data)
		{
			if(data.status == 'Success')
			{
				$("#kota").html("<option value=''>- Pilih Kota -</option>");
				var city_data = data.result;
				var city_length = data.result.length;
				
				for(var i = 0; i < city_length; i++)
				{
					var city = "<option value='"+city_data[i].city_id+"'>"+city_data[i].city_name+"</option>";
					
					$("#kota").append(city);
				}
			}	
				
		},"json");
		
		
	});	
	
	$("#kota").change(function(){
		
		var city_id = $(this).val(); 
		$("#kecamatan").html("<option value=''>Loading..</option>");
		//Get List kecamatan
		$.get(base_url_api+"/subdistrict",{token : token_api,domain : domain_api, city_id : city_id},function(data)
		{
			if(data.status == 'Success')
			{
				$("#kecamatan").html("<option value=''>- Pilih Kecamatan -</option>");
				var kec_data = data.result;
				var kect_length = data.result.length;
				
				for(var i = 0; i < kect_length; i++)
				{
					var kecamatan = "<option value='"+kec_data[i].subdistrict_id+"'>"+kec_data[i].subdistrict_name+"</option>";
					
					$("#kecamatan").append(kecamatan);
				}
			}	
				
		},"json");
		
	});	
	$("#add-back").click(function(){

		var this_redirect_url = $("#this_redirect_url").val();
		$("#redirect_url").val(this_redirect_url);

		$("#form-add-customer").submit();

		return false;

	});
	
</script>