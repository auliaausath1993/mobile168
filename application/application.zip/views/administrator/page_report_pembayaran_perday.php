<?php include "includes/header.php"; ?>

<script type="text/javascript">

var table_name = '<?= $table_name; ?>';

</script>

<!-- Content

================================================== -->

<div id="page-wrapper">



    <div class="container-fluid">



        <!-- Page Heading -->

        <div class="row">

            <div class="col-lg-12">

                <h1 class="page-header">

                    Lihat laporan Pembayaran (Harian) <small> Check laporan per hari</small>

                </h1>

                <ul id="submenu-container" class="nav nav-tabs" style="margin-bottom: 20px;">
                  <li <?php if ($this->uri->segment(3) == 'report_pembayaran_perday') { echo 'class="active"'; } ?>><a href="<?=base_url()?>administrator/main/report_pembayaran_perday" ><b>Laporan Pembayaran Harian</b></a></li>
                  <li><a href="<?=base_url()?>administrator/main/report_pembayaran_permonth" ><b>Laporan Pembayaran Bulanan</b></a></li>
                </ul>

                <ol class="breadcrumb">

                    <li class="active">

                        <i class="fa fa-list"></i> Laporan harian

                    </li>

                </ol>

            </div>

        </div>

        <!-- /.row -->

        <div class="row">

            <div class="col-lg-12">

            	

				<?=form_open('administrator/main/report_pembayaran_perday_process') ?>

	            	Tanggal : <input type="text" name="date" class="datepicker" data-date-format="yyyy-mm-dd"/>   
	            	
	            	Jenis Customer : <select name="jenis_customer" style="padding:6px;">
	            		<option value="All">Semua Customer</option>
	            		<option value="Lokal">Customer Lokal</option>
	            		<option value="Luar"> Customer Luar</option>
	            	</select>

					<button type="submit" class="btn btn-success"><i class="fa fa-search"></i> LIHAT LAPORAN</button>

				<?=form_close() ?>

            </div>

        </div>

    </div>

</div>



<?php include "includes/footer.php"; ?>

