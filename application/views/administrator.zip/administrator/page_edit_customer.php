<?php include "includes/header.php"; ?>

<script type="text/javascript">

var table_name = '<?= $table_name; ?>';

</script>

<!-- Content
================================================== -->

<div id="page-wrapper">

    <div class="container-fluid">

		<div class="row">

	        <div class="col-lg-12">
	            <h1 class="page-header">
	                Edit Customer
	            </h1>
	            <ol class="breadcrumb">
				
	                <li class="active">

	                    <i class="fa fa-fw fa-edit"></i> Edit Customer

	                </li>

	            </ol>

	        </div>

	    </div>
	    <!-- /.row -->
		<div class="row">
			<?=$this->session->flashdata('message') ?>
			<div class="col-lg-12">
				<div class="table-responsive add-product-wrapper">
				<form method="post" action="<?=base_url()?>administrator/main/edit_customer_process" id="form-edit-customer">
					<table class="table table-bordered table-striped">
						<tbody>
							<tr>
								<td width="25%">Nama Customer*</td>
								<td><input type="text" id="name-item" name ="name" class="input-text" title="masukkan nama customer anda" value="<?=$customer['name']?>" required ></td>
							</tr>
							<tr>
								<td width="25%">Email*</td>
								<td><input type="text" id="harga-modal" name ="email" class="input-text" title="masukkan Email customer anda" value="<?=$customer['email']?>" required ></td>
							</tr>
							<tr>
								<td width="25%">Password*</td>
								<?php $pass = $this->encrypt->decode($customer['password']);?>
								<td><input type="text" id="harga-jual" name ="password" class="input-text" value="<?=$pass?>" required></td>
							</tr>
							<tr>
								<td width="25%">Alamat</td>
								<td>
									<textarea id="deskripsi" name ="alamat" class="input-text" title="masukkan Alamat customer anda" maxlength="180" ><?=$customer['address']?></textarea><br/>
								</td>
							</tr>
							
							<tr>
								<td width="25%">Provinsi*</td>
								<td>
									<input type="hidden" name="detail_prov" id="detail_prov" value="<?=$customer['prov_id']?>">
									
									<select name="provinsi" class="select-text" id="provinsi" required>
										<option value="">- Pilih Provinsi -</option>
										
									</select>
								</td>
							</tr>
							<tr>
								<td width="25%">Kota*</td>
								<td>
									<select name="kota" class="select-text" id="kota" required>
										<?php if($customer['kota_id'] != 0){?>
											<script>
												var city_now = '<?=$customer['kota_id']?>';
												var province_now = '<?=$customer['prov_id']?>';
												var base_url_api = "http://api.tokomobile.co.id/ongkir/development/api";
												
												var token_api = "<?=$this->config->item('tokomobile_token')?>";
												var domain_api = "<?=$this->config->item('tokomobile_domain')?>";
												
												$.get(base_url_api+"/city",{token : token_api,domain : domain_api, province_id : province_now},function(data)
												{
													if(data.status == 'Success')
													{
														var kota_data = data.result;
														var kota_length = data.result.length;
														
														for(var i = 0; i < kota_length; i++)
														{
															if(city_now == kota_data[i].city_id)
															{
																var city = "<option value='"+kota_data[i].city_id+"' selected='selected'>"+kota_data[i].city_name+"</option>";
															}
															else
															{
																var city = "<option value='"+kota_data[i].city_id+"'>"+kota_data[i].city_name+"</option>";
															}
															$("#kota").append(city);
														}
														
													}	
														
												},"json");
											</script>
										<?php }else{?>
										<option value="">- Pilih Kota -</option>
										<?php }?>
									</select>
								</td>
							</tr>
							<tr>
								<td width="25%">Kecamatan*</td>
								<td>
									<select name="kecamatan" class="select-text" id="kecamatan" required>
										<?php if($customer['kecamatan_id'] != 0){?>
											<script>
												var subdistrict_now = '<?=$customer['kecamatan_id']?>';
												var city_now = '<?=$customer['kota_id']?>';
												var base_url_api = "http://api.tokomobile.co.id/ongkir/development/api";
												
												var token_api = "<?=$this->config->item('tokomobile_token')?>";
												var domain_api = "<?=$this->config->item('tokomobile_domain')?>";
												
												$.get(base_url_api+"/subdistrict",{token : token_api,domain : domain_api, city_id : city_now},function(data)
												{
													if(data.status == 'Success')
													{
														var kecamatan_data = data.result;
														var kecamatan_length = data.result.length;
				
														for(var i = 0; i < kecamatan_length; i++)
														{
															if(subdistrict_now == kecamatan_data[i].subdistrict_id)
															{
																var kecamatan = "<option value='"+kecamatan_data[i].subdistrict_id+"' selected='selected'>"+kecamatan_data[i].subdistrict_name+"</option>";
															}
															else
															{
																var kecamatan = "<option value='"+kecamatan_data[i].subdistrict_id+"'>"+kecamatan_data[i].subdistrict_name+"</option>";
															}
															$("#kecamatan").append(kecamatan);
														}
														
													}	
														
												},"json");
											</script>
										<?php }else{?>
										<option value="">- Pilih Kecamatan -</option>
										<?php }?>
									</select>
								</td>
							</tr>
							
							<tr> 
								<td width="25%">Kode Pos</td>
								<td><input type="text" id="harga-jual" name ="postcode" value="<?=$customer['postcode']?>" class="input-text" ></td>
							</tr>
							<tr>
								<td width="25%">Phone</td>
								<td><input type="text" id="harga-jual" name ="phone" value="<?=$customer['phone']?>" class="input-text" ></td>
							</tr>
							<tr>
								<td width="25%">Pin BB</td>
								<td><input type="text" id="harga-jual" name ="pinbb" value="<?=$customer['pin_bb']?>" class="input-text" ></td>
							</tr>
							<tr>
								<td width="25%">Jenis Customer*</td>
								<td>
									<select name="jenis_customer" class="select-text" id="jenis_customer" required>
									<?php foreach ($customertype as $row) { ?>
										<option value="<?= $row->id ?>" <?php if($customer['jenis_customer'] == $row->id){ echo 'selected="selected"';}?>><?= $row->name ?></option>
									<?php } ?>
									</select>
								</td>
							</tr>
							<tr>
								<td width="25%">Status*</td>
								<td>
									<select name="status" class="select-text" id="status" required>
										<option value="Active" <?php if($customer['status'] == 'Active'){echo 'selected="selected"';}?>>Active</option>
										<option value="Inactive" <?php if($customer['status'] == 'Inactive'){echo 'selected="selected"';}?>>Inactive</option>
										<option value="Moderate" <?php if($customer['status'] == 'Moderate'){echo 'selected="selected"';}?>>Moderate</option>
									</select>
								</td>
							</tr>
						</tbody>
					</table>
				</div>
				<div class="buttons-addproduct-wrapper">


					<input type="hidden" name="redirect_url" id="redirect_url"  value="" />
					<input type="hidden" name="id_data" id="id_data"  value="<?=$customer['id']?>" />
					<a href="#" id="add-back" class="btn btn-lg btn-default">Save</a>
					<button type="submit" id="add-product" class="btn btn-lg btn-default">Save and Back to List</button>
					<input type="hidden" name="this_redirect_url" id="this_redirect_url"  value="administrator/main/edit_customer/<?=$customer['id']?>" />	
					
					<a href="<?=base_url()?>administrator/main/customer" class="btn btn-lg btn-default">Cancel</a>
					
				</div>
				</form>
			</div>
		</div>
    </div>
 </div>

<?php include "includes/footer.php"; ?>

<script>

	
		
	var base_url_api = "http://api.tokomobile.co.id/ongkir/development/api";
	var token_api = "<?=$this->config->item('tokomobile_token')?>";
	var domain_api = "<?=$this->config->item('tokomobile_domain')?>";
	
	var detail_prov = $("#detail_prov").val();
	
	$.get(base_url_api+"/province",{token : token_api,domain : domain_api},
	function(data)
	{
		if(data.status == 'Success') 
		{
			var list_data = data.result;
			var list_length = data.result.length;
			
			for(var i = 0; i < list_length; i++)
			{
				if(detail_prov != list_data[i].province_id){
					var prov = "<option value='"+list_data[i].province_id+"'>"+list_data[i].province+"</option>";
				}
				else
				{
					var prov = "<option value='"+list_data[i].province_id+"' selected='selected'>"+list_data[i].province+"</option>";
				}
				
				$("#provinsi").append(prov);
			}
		}
			
	},"json");
	
	$("#provinsi").change(function(){
		
		var province_id = $(this).val(); 
		$("#kota").html("<option value=''>Loading..</option>");
		$("#kecamatan").html("<option value=''>Loading..</option>");
		//Get List Kota
		$.get(base_url_api+"/city",{token : token_api,domain : domain_api, province_id : province_id},function(data)
		{
			if(data.status == 'Success')
			{
				$("#kota").html("<option value=''>- Pilih Kota -</option>");
				var city_data = data.result;
				var city_length = data.result.length;
				
				for(var i = 0; i < city_length; i++)
				{
					var city = "<option value='"+city_data[i].city_id+"'>"+city_data[i].city_name+"</option>";
					
					$("#kota").append(city);
				}
			}	
				
		},"json");
		
		
	});	
	
	$("#kota").change(function(){
		
		var city_id = $(this).val(); 
		$("#kecamatan").html("<option value=''>Loading..</option>");
		//Get List kecamatan
		$.get(base_url_api+"/subdistrict",{token : token_api,domain : domain_api, city_id : city_id},function(data)
		{
			if(data.status == 'Success')
			{
				$("#kecamatan").html("<option value=''>- Pilih Kecamatan -</option>");
				var kec_data = data.result;
				var kect_length = data.result.length;
				
				for(var i = 0; i < kect_length; i++)
				{
					var kecamatan = "<option value='"+kec_data[i].subdistrict_id+"'>"+kec_data[i].subdistrict_name+"</option>";
					
					$("#kecamatan").append(kecamatan);
				}
			}	
				
		},"json");
		
	});	
	$("#add-back").click(function(){

		var this_redirect_url = $("#this_redirect_url").val();
		$("#redirect_url").val(this_redirect_url);

		$("#form-edit-customer").submit();

		return false;

	});
	
</script>