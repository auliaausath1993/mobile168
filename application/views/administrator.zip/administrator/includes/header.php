<?php

$data_user = $this->main_model->get_detail('users',array('id' => $this->session->userdata('webadmin_user_id')));

$data_confirmation = $this->db->select('COUNT(*) AS total')
	->get_where('confirmation',array('status' => 'Pending'))->row_array();

$data_customer = $this->db->select('COUNT(*) AS total')
	->get_where('customer',array('status' => 'Moderate'))->row_array();
$data_value_stock = $this->main_model->get_detail('content',array('id' => 10));
$data_toolstip = $this->main_model->get_detail('content',array('id' => 17));
$bts= $this->total_available_space_product;
$publish =$this->total_publish_product ;
$max = $this->total_max_product;
?>
<!DOCTYPE html>
<html lang="en">



<head>



    <meta charset="utf-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1">

    <meta name="description" content="">

    <meta name="author" content="">



    <title><?=$this->config->item('tokomobile_online_shop'); ?> - Administrator</title>

    <script src="<?= base_url() ?>application/views/administrator/assets/js/jquery.js"></script>
    <script type="text/javascript">
    var base_url = '<?= base_url() ?>';
    </script>

    <?php if($output != null) { ?>
        <?php foreach($output->css_files as $file): ?>
        <link type="text/css" rel="stylesheet" href="<?php echo $file; ?>" />
        <?php endforeach; ?>
    <?php } ?>



    <!-- Bootstrap Core CSS -->

    <link href="<?=base_url()?>application/views/administrator/assets/css/bootstrap.css" rel="stylesheet">



    <!-- Custom CSS -->

    <link href="<?=base_url()?>application/views/administrator/assets/css/sb-admin.css" rel="stylesheet">

	<link href='<?php echo base_url();?>assets/css/jquery.autocomplete.css' rel='stylesheet' />

    <link href="<?= base_url() ?>application/views/administrator/assets/css/site.css" rel="stylesheet">

    <link href="<?= base_url() ?>application/views/administrator/assets/js/datepicker/css/datepicker.css" rel="stylesheet">



    <link href="<?= base_url() ?>application/views/administrator/assets/css/jquery-multicomplete.css" rel="stylesheet" media="all" />

    <link href="<?= base_url() ?>application/views/administrator/assets/css/jquery.fs.tipper.css" rel="stylesheet" media="all" />
    <!-- Scrollbar -->

    <link rel="stylesheet" href="<?= base_url() ?>application/views/administrator/assets/css/jquery.mCustomScrollbar.css">

    <!-- Css Upload
        <link rel="stylesheet" href="<?= base_url() ?>application/views/administrator/assets/css/uploadfile.css">
    -->
    <!-- Custom Fonts -->

    <link href="<?=base_url()?>application/views/administrator/assets/font-awesome-4.1.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->

    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->

    <!--[if lt IE 9]>

        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>

        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>

    <![endif]-->
    <script type="text/javascript" src="<?=base_url()?>application/views/administrator/assets/js/jquery.fs.tipper.js"></script>
    <script type="text/javascript" src="<?=base_url()?>application/views/administrator/assets/js/Chart.min.js"></script>
    <?php if ($data_toolstip['value'] != 'OFF') { ?>
        <script type="text/javascript">
            jQuery(document).ready(function($) {
                $(".tipped").tipper({"direction":"right"});
            });
        </script>
    <?php } ?>

    <style type="text/css">
        table.table-grosir tr > th, table.table-grosir tr > td  {
            text-align: center;
            vertical-align: middle;
        }

        table.table-grosir input[type="text"] {
            width: 100%;
        }

        table.table-grosir {
            margin-bottom: 0px;
        }

        .navbar-inverse .nav .top-menu, .navbar-inverse .navbar-brand {
      		<?php
			$header_color = $this->main_model->get_detail('content',array('name' => 'header_color'));
      		$font_color = $this->main_model->get_detail('content',array('name' => 'font_color')); ?>

      		color: <?= $font_color['value'] ?> !important;
      	}
    </style>
    <script src="<?= mix('js/app.js') ?>" defer></script>
</head>

<body>

    <div class="slide-menu  slide-menu-left">
        <div class="sroll-bar">
            <!-- Navigation Responsive -->
            <?php include "sidebar-menu.php"; ?>
        </div>
    </div>

    <!-- Site Overlay -->
    <div class="site-overlay"></div>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" style="background:<?= $header_color['value'] ?>;" role="navigation">
            <?php include "top-menu.php"; ?>
            <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
             <div class="side-nav-wrapper fluid">
                <?php include "sidebar-menu.php"; ?>
            </div>
            <!-- /.navbar-collapse -->
        </nav>
        <div class="date-wrapper">
            <a href="#"><i class="fa fa-calendar"></i><?= date("D, d-M-Y") ?></a>
        </div>


