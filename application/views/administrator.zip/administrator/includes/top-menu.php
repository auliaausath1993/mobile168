<?php
	$header_color = $this->main_model->get_detail('content',array('name' => 'header_color'));
    $font_color = $this->main_model->get_detail('content',array('name' => 'font_color')); ?>
<div class="navbar-header" style="background:<?= $header_color['value'] ?>;">
    <button type="button" class="navbar-toggle menu-btn">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
    </button>
    <a class="navbar-brand" href="<?= base_url('administrator/main/dashboard') ?>">
    	<strong><?= $this->config->item('tokomobile_online_shop'); ?></strong>
    </a>
</div>
<!-- Top Menu Items -->
<div id="load_content">
    <ul id="load_content" class="nav navbar-right top-nav">
        <li react-component="OrderKeep" class="dropdown"></li>
        <li react-component="OrderRekap" class="dropdown"></li>
        <li react-component="OrderDropship" class="dropdown"></li>
        <li class="dropdown">
            <a href="<?=base_url()?>administrator/main/confirm_payment" class="top-menu" id="confirm">
            	<i class="fa fa-inbox"></i>&nbsp;
            	<span>Konfirmasi</span>
                <?php if($data_confirmation['total'] > 0) { ?>
                <span class="label label-danger" id="qty-konfirmasi"><?=$data_confirmation['total']?></span>
                <?php } ?>
            </a>
        </li>
        <li class="dropdown">
            <a href="#" class="dropdown-toggle  top-menu" data-toggle="dropdown"><i class="fa fa-user"></i> <span>Akun</span> <b class="caret"></b></a>
            <ul class="dropdown-menu">
                <li>
                    <a href="<?=base_url()?>administrator/main/edit_profile"><i class="fa fa-fw fa-user"></i> Profil</a>
                </li>
                <li>
                    <a href="<?=base_url()?>administrator/main/message"><i class="fa fa-fw fa-envelope"></i> Pesan</a>
                </li>
                <li class="divider"></li>
                <li>
                    <a href="<?=base_url()?>administrator/main/logout"><i class="fa fa-fw fa-power-off"></i> Keluar</a>
                </li>
            </ul>
        </li>
    </ul>
</div>