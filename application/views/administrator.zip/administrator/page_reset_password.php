<!DOCTYPE html>

<html lang="en"><head>

<meta http-equiv="content-type" content="text/html; charset=UTF-8">

    <title>Reset Password Admin</title>

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <meta charset="utf-8">

	

    <link rel="stylesheet" href="<?= base_url() ?>application/views/administrator/assets/bootstrap/css/bootstrap.css" media="screen">

	<link rel="stylesheet" href="<?= base_url() ?>application/views/administrator/assets/css/login.css" media="all">





    <link href="<?= base_url() ?>application/views/administrator/assets/bootstrap/css/bootstrap-responsive.css" rel="stylesheet">



    <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->

    <!--[if lt IE 9]>

      <script src="../assets/js/html5shiv.js"></script>

    <![endif]-->



    <!-- Fav and touch icons -->

    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="../assets/ico/apple-touch-icon-144-precomposed.png">

    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="../assets/ico/apple-touch-icon-114-precomposed.png">

    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="../assets/ico/apple-touch-icon-72-precomposed.png">

    <link rel="apple-touch-icon-precomposed" href="../assets/ico/apple-touch-icon-57-precomposed.png">

    <link rel="shortcut icon" href="../assets/ico/favicon.png">

  </head>

  <?php 
    $data_version = $this->main_model->get_list('data_version_update',array('perpage' => 1,'offset' => 0),array('by' => 'id','sorting' => 'DESC'));
    $data_array_version_last = $data_version->row_array();
    $name_last_vertion = $data_array_version_last['name_version'];
  ?>


  <body>



    <div class="container">

	<?= $this->session->flashdata('message'); ?>

  <div id="alret_sucsess" class="alert alert-sucsess" role="alert" hidden>
    <strong>Activation Sucsess : </strong>UTerimakasih anda telah berhasil melakukan activasi.
  </div>

	<br/><br/><br/><br/>

     <?=form_open('administrator/forgot/reset_password_process',array('class' => 'form-signin')); ?>

        

		<h4>Halaman Reset Password</h4>
		
		<h5>Masukan Password Baru :</h5>

        <input type="password" class="input-block-level" name="password" placeholder="Password baru anda">
		
		<h5>Ulangi Password :</h5>

        <input type="password" class="input-block-level" name="password_confirm" placeholder="Ulangi password anda">
        
		
        <button class="btn btn-large btn-inverse" type="submit" data-loading-text="Loading.. ">Kirim</button>
		
		<input type="hidden"  name="code" value="<?=$code?>" >
     <?=form_close()?>



	<center>

	<p class="powered">Powered by <b>TokoMobile </b>Ver. <?php echo $name_last_vertion; ?><br/>

	Aplikasi Smartphone Online Shop

	</p>

	

	</center>

    </div>



	<div class="bottom-navbar"><strong>TOKOMOBILE</strong>

	</div>

    <script src="<?= base_url() ?>application/views/administrator/assets/js/jquery.js"></script>

    <script src="<?= base_url() ?>application/views/administrator/assets/bootstrap/js/bootstrap.js"></script>

	<script src="<?= base_url() ?>application/views/administrator/assets/js/jquery.js"></script>

	<script>

		setTimeout("$('.form-signin').fadeIn('slow');",400);

		setTimeout("$('.powered').fadeIn('slow');",1000);

    $.post( base_url+"administrator/activation/activation_process", { code: code, expired_date: data.expired_date, paket: data.paket, token: data.token},
       function( data ) {

          if(data.status == 'Success')
          {
              $('#alret_sucsess').modal('show');
          }  

    }, "json");

	</script>

</body>

</html>

