<?php include "includes/header.php"; ?>





<!-- Content

================================================== -->



<div id="page-wrapper">

    <div class="container-fluid">



	    <!-- Page Heading -->

	    <div class="row">



	        <div class="col-lg-12">

	            <h1 class="page-header">

	               Kirim Pesan (multiple)

	            </h1>



	            <ul id="submenu-container" class="nav nav-tabs" style="margin-bottom: 20px;">

                  	<li><a href="<?=base_url()?>administrator/main/message_add" ><b>Kirim Pesan</b></a></li>

                  	<li class="active"><a href="<?=base_url()?>administrator/main/message_to_multiple" ><b>Kirim Pesan (Multiple)</b></a></li>

                	<li><a href="<?=base_url()?>administrator/main/message" ><b>History Pesan</b></a></li>

                </ul>



	            <ol class="breadcrumb">

	                <li class="active">

	                    <i class="fa fa-fw fa-edit"></i>  Kirim Pesan (multiple)

	                </li>

	            </ol>

	        </div>



	    </div>



	    <!-- /.row -->



    	<?=$this->session->flashdata('message') ?>



	

		<?=form_open('administrator/main/message_to_multiple_process', array('role'=>'form','enctype'=>'multipart/form-data')); ?>



			<div class="row">



			<div class="col-md-6">



			<p><strong>Subjek</strong></p>


			<input type="hidden" name="url" value="message_multiple">
			<input type="text" name="subject"  class="form-control" placeholder="Ketik Disini..."/><br/>

			<p><strong>Gambar</strong></p>
			<input type="file" onchange="readURL(this);" id="image" name="image" accept=".png, .jpg, .jpeg">
			<img id="previewImage"><br>

			<p><strong>Pesan</strong></p>



			<textarea name="content" rows="10"  class="form-control" placeholder="Ketik Disini..."></textarea><br/>



			<button type="submit" name="btn_send" class="btn btn-success">Kirim</button>



			</div>



			<div class="col-md-6">



			<p><strong>Penerima</strong></p>



			<select type="select-multiple" multiple="multiple" class="form-control" style="height:200px;" id="customer_id" name="customer_id[]" >



			



			<?php foreach($list_customer->result() as $customers): ?>



				<option value="<?=$customers->id ?>"><?=$customers->name?> (<?=$customers->id ?>) </option>



			<?php endforeach; ?>



			</select>



			<br/>



			<button type="button" id="select_all" class="btn btn-info">Select All</button>



			</div>



		</div>



		



		<?=form_close()?>



		<br/>



    </div>







 </div>







<?php include "includes/footer.php"; ?>



<script type="text/javascript">



$('#select_all').click(function() {



    $('#customer_id option').prop('selected', true);



});

	function readURL(input) {
		if (input.files && input.files[0]) {
			var reader = new FileReader();

			reader.onload = function (e) {
				$('#previewImage')
				.attr('src', e.target.result)
				.width(200);
			};

			reader.readAsDataURL(input.files[0]);
		}
	}

</script>