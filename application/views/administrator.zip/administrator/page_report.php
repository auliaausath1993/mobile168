<?php include "includes/header.php"; ?>
<script type="text/javascript">
var table_name = '<?= $table_name; ?>';
</script>
<!-- Content
================================================== -->
<section id="content">

  <!-- Headings & Paragraph Copy -->
  <div class="row">

    <div class="span12">
		<div class="well">
		<h3>Lihat laporan penjualan</h3>
		Bulan : 
		<select name="bulan">
			<option value="">- Pilih bulan -</option>
			<option value="1">Januari</option>
			<option value="2">Februari</option>
			<option value="3">Maret</option>
			<option value="4">April</option>
			<option value="5">Mei</option>
			<option value="6">Juni</option>
			<option value="7">Juli</option>
			<option value="8">Agustus</option>
			<option value="9">September</option>
			<option value="10">Oktober</option>
			<option value="11">November</option>
			<option value="12">Desember</option>
			
		</select> 
		Tahun : 
		<select name="bulan">
			<option value="">- Pilih tahun -</option>
			<option value="2014">2014</option>
			<option value="2015">2015</option>
			<option value="2016">2016</option>
		
			
		</select>
		<br/>
		<button type="submit" class="btn btn-success"><i class="icon-search icon-white"></i> LIHAT LAPORAN</button>
		</div>
	</div>

  </div>
  
 

</section>

<?php include "includes/footer.php"; ?>
