<?php include "includes/header.php"; ?>
<!-- Content
================================================== -->
<div id="page-wrapper">
    <div class="container-fluid">
	   	<!-- Page Heading -->
	    <div class="row">
	        <div class="col-lg-12">
	            <?php if ($this->uri->segment(3) == 'order_unpaid' or $this->uri->segment(3) == 'order_unpaid_expired' ) { ?>
	            	<h1 class="page-header">
		                Pesanan <small> Dalam Proses </small>
		            </h1>
		            <ul id="submenu-container" class="nav nav-tabs" style="margin-bottom: 20px;">
	                  	<li><a href="<?=base_url()?>administrator/main/last_order_process" ><b>Keep (Belum Lunas)</b></a></li>
	                  	<li><a href="<?=base_url()?>administrator/main/last_order_process_by_variant" ><b>Keep Per Produk</b></a></li>
	                	<?php if ($this->uri->segment(3) == 'order_unpaid') { ?>
						<li class="active"><a href="<?=base_url()?>administrator/main/order_unpaid" ><b>Dropship Belum Lunas</b></a></li>
	                	<li><a href="<?=base_url()?>administrator/main/last_order_process_expired" ><b>Keep Jatuh Tempo</b></a></li>
						<li><a href="<?=base_url()?>administrator/main/order_unpaid_expired" ><b>Dropship Jatuh Tempo</b></a></li>
						<?php }elseif($this->uri->segment(3) == 'order_unpaid_expired' ) { ?>
						<li><a href="<?=base_url()?>administrator/main/order_unpaid" ><b>Dropship Belum Lunas</b></a></li>
	                	 <li >
		    		    	<a href="<?=base_url()?>administrator/main/last_order_process_expired" >
		    		    		<b>Jatuh Tempo (Keep)</b>
		    		    	</a>
		    		    </li> 
						<li class="active"><a href="<?=base_url()?>administrator/main/order_unpaid_expired" ><b>Jatuh Tempo (Dropship)</b></a></li>
						<?php } ?>
	                </ul>
	                <ol class="breadcrumb">
		                <li class="active">
		                    <i class="fa fa-fw fa-list"></i> Pesanan Dropship Belum Lunas
		                </li>
		            </ol>	
	            <?php }else{
	            	if ($this->uri->segment(3) == 'report_autocancel') {
	            		$header_title = 'Laporan';
	            	} else {
	            		$header_title = 'Pesanan';
	            	}?>
	            	<h1 class="page-header">
		                <?= $header_title ?> <small> <?=$order_payment?> </small>
		            </h1>
	            <?php } ?>
	        </div>
	    </div>
	    <!-- /.row -->
    
    	<?=$this->session->flashdata('message') ?>
		
		<div id="list_orders">
		<?= $output->output; ?> 
		</div>
		<br/>
		<?php if ($order_payment == 'Dropship Belum Lunas'){?>
		<input type="button" class="btn btn-md btn-success" id="btn_check_lunas" value="LUNAS CHECKED" />
			<?php if($this->uri->segment(3) == 'order_unpaid_expired' ) { ?>
			<input type="button" class="btn btn-md btn-danger" id="btn_check_batal" value="BATALKAN CHECKED" />
			<?php }?>
		<?php }?>
    </div>
 </div>
 
<?php include "includes/footer.php"; ?>
<?php if($output->output != null) { ?>
	<?php foreach($output->js_files as $file): ?>
	<script src="<?php echo $file; ?>"></script>
	<?php endforeach; ?>
	<?php } ?>
<script type="text/javascript">
$("#btn_check_lunas").click(function(){
	var list = "";
	var base_url = "<?=base_url() ?>";
	
	var ch = new Array();
	
	$('#list_orders input:checkbox:checked').each(function() {     
	
		ch.push($(this).val());
	});
	
	var list_order = "["+ch+"]";
	$.post( base_url+"administrator/main/order_process_to_paid", { list_order : list_order}, function( data ) {
		
		if(data.pesan == 'Success')
		{
			window.location.reload(true); 
		} else {
			alert("Data pesanan gagal diubah");
		}	
	}, "json");
});
$("#btn_check_batal").click(function(){
	var list = "";
	var base_url = "<?=base_url() ?>";
	
	var ch = new Array();
	
	$('#list_orders input:checkbox:checked').each(function() {     
	
		ch.push($(this).val());
	});
	
	var list_order = "["+ch+"]";
	$.post( base_url+"administrator/main/order_process_to_batal", { list_order : list_order}, function( data ) {
		
		if(data.pesan == 'Success')
		{
			window.location.reload(true); 
		} else {
			alert("Data pesanan gagal diubah");
		}	
	}, "json");
});
</script>